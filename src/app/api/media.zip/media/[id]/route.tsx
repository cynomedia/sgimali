import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const mediaId = params.id;

  if (!mediaId) {
    return NextResponse.json(
      { error: 'Media ID is required' },
      { status: 400 }
    );
  }

  const apiUrl = `https://sgi.cynomedia-africa.com/wp-json/wp/v2/media/${mediaId}`;

  try {
    const response = await fetch(apiUrl);

    if (!response.ok) {
      const errorData = await response.text();
      return NextResponse.json(
        { error: `Failed to fetch media: ${errorData}` },
        { status: response.status }
      );
    }

    const mediaData = await response.json();

    // Renvoyer uniquement l'URL sans révéler la source
    return NextResponse.json({ fileUrl: mediaData.source_url });
  } catch (error: unknown) {
    console.error('Error in proxy:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
