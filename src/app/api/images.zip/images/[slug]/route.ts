import { NextResponse } from 'next/server';

// Cette fonction gère la requête GET et sert l'image via un proxy
export async function GET(request: Request, { params }: { params: { slug: string } }) {
  // Vous devez attendre la résolution de la route dynamique avant d'utiliser params
  const { slug } = params;

  // Validation que le slug est valide
  if (!slug || slug.trim() === '') {
    return NextResponse.json({ error: 'Slug is invalid or missing' }, { status: 400 });
  }

  // Construire l'URL de l'API WordPress en fonction du slug
  const apiUrl = `https://sgi.cynomedia-africa.com/wp-json/wp/v2/media?slug=${slug}`;

  try {
    // Requête pour récupérer le média via son slug
    const response = await fetch(apiUrl);

    if (!response.ok) {
      const errorData = await response.text();
      return NextResponse.json(
        {
          error: `Failed to fetch media. Error: ${errorData}`,
        },
        { status: response.status }
      );
    }

    // Si la réponse est correcte, récupérer les données du média
    const mediaData = await response.json();

    if (!mediaData || mediaData.length === 0) {
      return NextResponse.json({ error: 'Media not found' }, { status: 404 });
    }

    // Récupérer l'URL du fichier image directement à partir du champ guid.rendered
    const imageUrl = mediaData[0].guid.rendered;
    const mimeType = mediaData[0].mime_type; // Le type MIME de l'image

    // Vérification de l'URL de l'image
    if (!imageUrl) {
      return NextResponse.json({ error: 'Image URL not found' }, { status: 404 });
    }

    // Faire une requête pour récupérer l'image
    const imageResponse = await fetch(imageUrl);

    // Vérification si l'image est correctement récupérée
    if (!imageResponse.ok) {
      return NextResponse.json({ error: 'Failed to fetch image' }, { status: 500 });
    }

    // Récupérer le type de contenu de l'image
    const contentType = mimeType || imageResponse.headers.get('Content-Type');
    const imageBuffer = await imageResponse.arrayBuffer();

    // Retourner l'image avec le bon Content-Type
    return new NextResponse(Buffer.from(imageBuffer), {
      headers: {
        'Content-Type': contentType, // L'extension est incluse dans le type MIME
      },
    });
  } catch (error: unknown) {
    console.error('Error fetching image:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
