export default async (req, res) => {
    const { imageName } = req.query; // Récupère le nom de l'image depuis l'URL
  
    // Exemple d'extraction dynamique de paramètres pour le chemin (peut être modifié en fonction de votre logique)
    const year = imageName.split('-')[2]; // Extrait l'année du nom du fichier, exemple: 'capture-decran-2024-12-10-a-09-03-45'
    const month = imageName.split('-')[3]; // Extrait le mois du nom du fichier
    
    // Construire l'URL externe de l'image avec des paramètres dynamiques
    const externalUrl = `https://sgi.cynomedia-africa.com/wp-content/uploads/${year}/${month}/${imageName}.webp`;
  
    try {
      // Effectuer la requête `fetch` vers l'URL externe
      const response = await fetch(externalUrl);
  
      // Vérifier si l'image existe
      if (!response.ok) {
        res.status(404).json({ error: 'Image not found' });
        return;
      }
  
      // Répondre avec l'image depuis l'URL externe
      res.setHeader('Content-Type', response.headers.get('Content-Type'));
      response.body.pipe(res); // Envoie l'image à l'utilisateur
    } catch (error) {
      res.status(500).json({ error: 'Unable to fetch image' });
    }
  };
  